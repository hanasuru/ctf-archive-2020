from secret import flag

def xor(data, key):
    l = len(key)
    str=''
    for i in range(0,len(data)):
    	str+=chr(ord(data[i])^ord(key[i%l]))
    return str

if __name__ == '__main__':
	data = (open('plaintext', 'rb').read())
	assert(len(flag)==33)
	
	key1 = flag[:17]
	key2 = flag[17:]
	a = xor(data,key1)
	b = xor(a,key2)
	open('ciphertext.txt','w').write(b)
