<?php

require_once 'vendor/autoload.php';

use Orbitale\Component\ImageMagick\Command;
// Create a new command
$command = new Command("/usr/bin/magick");
$response = $command
    // The command will search for the "logo.png" file. If it does not exist, it will throw an exception.
    // If it does, it will create a new command with this source image.
    // ->convert('$(id>hacked).jpg')
    ->convert('logo.jpg')

    // The "output()" method will append "logo.gif" at the end of the command-line instruction as a filename.
    // This way, we can continue writing our command without appending "logo.gif" ourselves.
    ->output('/tmp/logo.gif')

    ->resize('50x50')
    // At this time, the command shall look like this :
    // $ "{ImageMagickPath}convert" "logo.png" "logo.gif"

    // Then we run the command by using "exec()" to get the CommandResponse
    ->run()
;

// Check if the command failed and get the error if needed
if ($response->hasFailed()) {
    throw new Exception('An error occurred:'.$response->getError());
} else {
    // If it has not failed, then we simply send it to the buffer
    // header('Content-type: image/gif');
    echo "DONE";
    // echo file_get_contents('/tmp/logo.gif');
}


