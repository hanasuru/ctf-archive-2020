<?php

$kamu = "aku";
$die = "mati";
$dia = "heker";
$mati = "mampus";
$exe = "cinta";
$cinta = "tema";
$heker = "die";
$mampus = "exe";
$aku = "dia";