package main

// #cgo CFLAGS: -g -Wall
// #include <stdlib.h>
// #include <stdio.h>
import "C"
import (
	"bufio"
	"fmt"
	"os"
	"unsafe"
)

var (
	weapon     [16]*C.char
	itemBought int
)

func banner() {
	fmt.Println("Bot Minh: RUSH B!")
	fmt.Println("Bot Cliffe: Affirmative")
	fmt.Println("\nBuy phase")
}

func menu() int {
	var choice int
	fmt.Println("1. buy weapon")
	fmt.Println("2. drop weapon")
	fmt.Println("3. view weapon")
	fmt.Println("4. go go go!")
	fmt.Print("choice: ")
	fmt.Scanf("%d", &choice)
	return choice
}

func buy() {
	var i int
	if itemBought >= 16 {
		return
	}
	for i = 0; i < 16; i++ {
		if unsafe.Pointer(weapon[i]) == nil {
			break
		}
	}
	if i == 16 {
		return
	}
	fmt.Print("weapon name: ")
	reader := bufio.NewReader(os.Stdin)
	text, _ := reader.ReadString('\n')
	weapon[i] = C.CString(text)
	itemBought++
}

func drop() {
	var ask uint
	fmt.Print("weapon slot: ")
	fmt.Scanf("%d", &ask)
	if weapon[ask] == nil || ask > 15 {
		return
	}
	defer C.free(unsafe.Pointer(weapon[ask]))
	itemBought--
}

func view() {
	var ask int
	if weapon[ask] == nil || ask > 15 {
		return
	}
	fmt.Print("weapon slot: ")
	fmt.Scanf("%d", &ask)
	C.puts(weapon[ask])
}

func init() {
	itemBought = 0
}

func main() {
	exit := false

	banner()
	for !exit {
		choice := menu()
		switch choice {
		case 1:
			buy()
		case 2:
			drop()
		case 3:
			view()
		case 4:
			exit = true
		}
	}
}
